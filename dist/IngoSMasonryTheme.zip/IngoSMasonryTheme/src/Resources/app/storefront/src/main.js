import IngoSMasonryTheme from './ingos-masonry-theme/ingos-masonry-theme';
// Import other plugins if necessary
// Register your plugin via the existing PluginManager
const PluginManager = window.PluginManager;
PluginManager.register('IngoSMasonryTheme', IngoSMasonryTheme);
