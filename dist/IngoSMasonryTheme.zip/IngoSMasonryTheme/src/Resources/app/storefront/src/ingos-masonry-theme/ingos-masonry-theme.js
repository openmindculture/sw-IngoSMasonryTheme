import Plugin from 'src/plugin-system/plugin.class';

// <plugin root>/src/Resources/app/storefront/src/example-plugin/example-plugin.plugin.js


export default class IngosMasonryTheme extends Plugin {
    init() {
        // this.addAnimationEffectClassNames();
    }
    addAnimationEffectClassNames() {
        // const animatableElements = document.querySelectorAll('.ingos-cost-group');
        // for (let i=0; i < animatableElements.length; i++) {
        //    animatableElements[i].addEventListener('click', this.costGroupEnterHandler);
        // }
    }
}