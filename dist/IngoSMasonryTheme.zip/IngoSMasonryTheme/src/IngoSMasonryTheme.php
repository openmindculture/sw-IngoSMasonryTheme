<?php declare(strict_types=1);

namespace IngoSMasonryTheme;

use Shopware\Core\Framework\Plugin;
use Shopware\Storefront\Framework\ThemeInterface;

class IngoSMasonryTheme extends Plugin implements ThemeInterface
{
}